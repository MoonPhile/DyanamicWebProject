package mvc.Controller;

import mvc.database.DBConnection;
import mvc.model.UserInfo;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/UserInfoListServlet")
public class UserInfoListServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setCharacterEncoding("UTF-8");
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=utf-8");
        Connection conn=null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        ResultSetMetaData rsmd = null;
        try {
            conn = DBConnection.getConnection();
            pstmt = conn.prepareStatement("SELECT * From userinfo");
            rs = pstmt.executeQuery();
            List<UserInfo> userInfos = new ArrayList<UserInfo>();
            while (rs.next()){
                UserInfo userInfo = new UserInfo();
                userInfo.setId(rs.getString(1));
                userInfo.setPw(rs.getString(2));
                userInfo.setName(rs.getString(3));
                userInfos.add(userInfo);
            }
            request.setAttribute("userinfos",userInfos);
            RequestDispatcher rd = request.getRequestDispatcher("UserInfoList.jsp");
            rd.include(request,response);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
            } catch (Exception e) {}
        }
    }
}
