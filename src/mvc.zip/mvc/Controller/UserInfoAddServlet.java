package mvc.Controller;

import mvc.database.DBConnection;
import mvc.model.UserInfo;
import mvc.model.UserInfoDaoImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

@WebServlet("/UserInfoAddServlet")
public class UserInfoAddServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            UserInfoDaoImpl userInfoDao = new UserInfoDaoImpl();
            userInfoDao.insert(new UserInfo().setId(request.getParameter("id")).setPw(request.getParameter("pw")).setName(request.getParameter("name")));
            response.sendRedirect("UserInfoListServlet");
        } catch (Exception e) {
            response.sendRedirect("usedID.jsp");
        }
    }


    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    }

}
