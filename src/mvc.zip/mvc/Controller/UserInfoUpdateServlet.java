package mvc.Controller;

import mvc.model.UserInfo;
import mvc.model.UserInfoDaoImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
@WebServlet("/UserInfoUpdateServlet")
public class UserInfoUpdateServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            UserInfoDaoImpl userInfoDao = new UserInfoDaoImpl();
            userInfoDao.update(new UserInfo().setId(request.getParameter("id")).setPw(request.getParameter("pw")).setName(request.getParameter("name")));
            response.sendRedirect("UserInfoListServlet");
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
