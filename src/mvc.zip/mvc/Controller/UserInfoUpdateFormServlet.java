package mvc.Controller;

import mvc.model.UserInfo;
import mvc.model.UserInfoDaoImpl;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
@WebServlet("/UserInfoUpdateFormServlet")
public class UserInfoUpdateFormServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html; charset=utf-8");
        try {
            UserInfoDaoImpl userInfoDao = new UserInfoDaoImpl();
            UserInfo userInfo = userInfoDao.selectOne(request.getParameter("id"));
            request.setAttribute("userInfo",userInfo);
            RequestDispatcher rd = request.getRequestDispatcher("userInfoView.jsp");
            rd.include(request,response);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
