package mvc.Controller;

import mvc.model.UserInfo;
import mvc.model.UserInfoDaoImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/UserInfoLoginServlet")
public class UserInfoLoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
        try {
            UserInfoDaoImpl userInfoDao = new UserInfoDaoImpl();
            UserInfo userInfo = userInfoDao.exist(request.getParameter("id"), request.getParameter("pw"));
            if(userInfo != null){
                HttpSession session = request.getSession();
                session.setAttribute("userInfo",userInfo);
                response.sendRedirect("UserInfoListServlet");
            }else {
                response.sendRedirect("UserInfoLogin.jsp");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
